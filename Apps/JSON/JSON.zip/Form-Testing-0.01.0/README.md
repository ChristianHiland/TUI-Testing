# Learning How To Use JSONs

## English

I'm learning how to work with JSONs, by asking questions, then putting them info a JSON, and then printing them out.

To start open a terminal, but before make sure you unziped the zip file. From there go into the folder that has the just now unzipped file, then run MainEN.py, and follow the prompts on the terminal.

## 한국어

질문을 한 다음 JSON에 정보를 입력하고 인쇄하여 JSON으로 작업하는 방법을 배우고 있습니다.

한국어 버전의 경우 시작하려면 터미널을 열되 zip 파일의 압축을 풀었는지 확인하십시오. 거기에서 방금 압축을 푼 파일이 있는 폴더로 이동한 다음 'Korean' 폴더로 이동한 다음 MainKO.py를 실행하고 터미널의 프롬프트를 따릅니다.
