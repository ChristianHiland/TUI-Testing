#!/usr/bin/env python3
from customtkinter import *

# Custom Vars

# Title Font
titleFont = CTkFont(size=30)