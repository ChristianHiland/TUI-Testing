![PyKorean Logo](Images/Icons/PyKorean.png)

# PyKorean

PyKorean is a project that is being worked on by a developer called Lunbin Hiland, English name is 룬반 (Christian.)

There isn't any runables for any OSs right now but in Linux there is as long as you have Python and CTk installed.

Developer/Layout: Christian

There is over 60 words in version 1.4
