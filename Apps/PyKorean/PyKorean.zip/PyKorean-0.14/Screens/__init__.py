#!/usr/bin/env python3
from Screens.About import AboutScreen
from Screens.LanguageS import LanguageScreen
from Screens.SettingsS import SettingScreen
from Screens.Update import UpdateScreen