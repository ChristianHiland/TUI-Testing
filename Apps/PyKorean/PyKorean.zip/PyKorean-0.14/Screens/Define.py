#!/usr/bin/env python3
from customtkinter import *

# Custom Vars

# Title Font
TitleFont = CTkFont(size=30)
NamesFont = CTkFont(size=20)
OutFont = CTkFont(size=17)